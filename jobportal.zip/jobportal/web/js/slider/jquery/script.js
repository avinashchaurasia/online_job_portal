// <![CDATA[
$(function() {

  // Slider
  $('#coin-slider').coinslider({width:277,height:163,opacity:1});

  

});	
