-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 16, 2015 at 12:54 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jobportalbansthli`
--

-- --------------------------------------------------------

--
-- Table structure for table `applied_candidate`
--

CREATE TABLE IF NOT EXISTS `applied_candidate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `applied_candidate`
--

INSERT INTO `applied_candidate` (`id`, `company`, `email`, `username`, `user_email`, `contact`) VALUES
(15, 'HCL', 'aartigugalia94@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(14, 'HCL', 'aartigugalia94@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(5, 'TCS', 'jainmansi1892@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(6, 'TCS', 'jainmansi1892@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(17, 'HCL', 'aartigugalia94@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(16, 'HCL', 'aartigugalia94@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(9, 'TCS', 'jainmansi1892@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(13, 'HCL', 'aartigugalia94@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(12, 'HCL', 'aartigugalia94@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(18, 'HCL', 'aartigugalia94@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192'),
(19, 'IBM', 'sharma.anjali2792@gmail.com', 'Party', 'partyprinces@gmail.com', '3456782192');

-- --------------------------------------------------------

--
-- Table structure for table `company_registration`
--

CREATE TABLE IF NOT EXISTS `company_registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `companyadd` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `grade` varchar(255) DEFAULT NULL,
  `status` int(4) DEFAULT NULL,
  `loginAs` varchar(255) DEFAULT NULL,
  `Auth_Code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `company_registration`
--

INSERT INTO `company_registration` (`id`, `name`, `email`, `pass`, `logo`, `companyadd`, `type`, `contact`, `grade`, `status`, `loginAs`, `Auth_Code`) VALUES
(4, 'TCS', 'jainmansi1892@gmail.com', 'HWX6be++3ANwr1Xmvr+j3w==', 'null', 'Mumbai', 'NonIT', '9843564432', 'A', 1, 'company', '2wZH8MXvr9Aj'),
(2, 'HCL', 'aartigugalia94@gmail.com', '66JVkMgdYeHpLUZ8FgFN7A==', '1441194_571415106263612_2135944293_n.png', 'jaipur', 'IT', '9786574378', 'A', 1, 'company', '587ua7yuXd@r'),
(14, 'genx', 'genx@gmail.com', 'RAMjf8qAMFFZ5gdLbpz2pA==', 'meetu-copy.jpg', '', '', 'null', 'B', 0, 'company', 'WM*HmN2krS8q'),
(12, 'IBM', 'sharma.anjali2792@gmail.com', 'D+wbbx0MH2FXu8/IxCc4dw==', '3.jpg', '', '', 'null', 'B', 1, 'company', 'RTtnHc9R@Xjy'),
(16, 'wipro', 'wipro@gmail.com', 'aiBL2J88g0iv1cd8cXoJeg==', '3.jpg', 'delhi', 'iT', '123456789', 'A', 1, 'company', 'rqmyGpw3BCPF'),
(17, 'newcompany', 'new@gmail.com', 'aiBL2J88g0iv1cd8cXoJeg==', '3.jpg', 'new', 'IT', 'null', '0', 0, 'company', 'QZ4SSrw8EWhF'),
(18, 'surbhi', 'genx.surbhi.jpr@gmail.com', 'I7QxrP60HhXUZtdd6CIwfA==', '3.jpg', 'h', 'h', 'null', '0', 0, 'company', 'R3Jj$v9x*m2C');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE IF NOT EXISTS `contactus` (
  `Name` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`Name`, `Email`, `address`) VALUES
('anjali', 'partyprinces@gmail.com', 'helooo');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `FullName` varchar(255) DEFAULT NULL,
  `ContactNumber` varchar(255) DEFAULT NULL,
  `Query` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FullName`, `ContactNumber`, `Query`) VALUES
('abcd', '121343', ''),
('anjali', '9677889901', 'which company'),
('aarti', 'acd', ''),
('ritu', '', ''),
('ritu', '2345678910', ''),
('', '', ''),
('', '', ''),
('surbhi', '1234567890', 'hello genx'),
('surbhi', '1234567890', 'hello genx');

-- --------------------------------------------------------

--
-- Table structure for table `jobdetail`
--

CREATE TABLE IF NOT EXISTS `jobdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `jobid` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `post` varchar(255) DEFAULT NULL,
  `criteria` varchar(255) DEFAULT NULL,
  `vaccancy` varchar(255) DEFAULT NULL,
  `salary` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `expyr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `jobdetail`
--

INSERT INTO `jobdetail` (`id`, `name`, `jobid`, `email`, `post`, `criteria`, `vaccancy`, `salary`, `city`, `type`, `expyr`) VALUES
(22, 'TCS', '120', 'jainmansi1892@gmail.com', 'Developer', '23', '9', '30000', 'Mumbai', 'IT', '2'),
(23, 'Aricent', '234', 'jainmansi1892@gmail.com', 'J.EN.', '67', '1', '50000', 'Agra', 'NonIT', '5'),
(21, 'HCL', '2', 'aartigugalia94@gmail.com', 'assistant manager', '40', '2', '30000', 'Gurgaon', 'Banking', '2'),
(20, 'HCL', '1', 'aartigugalia94@gmail.com', 'manager', '60', '1', '50000', 'delhi', 'IT sector', '5'),
(24, 'wipro', '23', 'wipro@gmail.com', 'Software Developer', '2', '25', '4.3', 'delhi', 'IT', '2'),
(25, 'newjob', 'job123', 'new@gmail.com', 'manager', '10', '5', '10', 'jaipu', 'IT', '2');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `Myname` varchar(255) DEFAULT NULL,
  `Iam` varchar(255) DEFAULT NULL,
  `Birthday` varchar(255) DEFAULT NULL,
  `Ilivein` varchar(255) DEFAULT NULL,
  `CollegeName` varchar(255) DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `uploadpic` varchar(255) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `loginAs` varchar(255) DEFAULT NULL,
  `Auth_Code` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Myname`, `Iam`, `Birthday`, `Ilivein`, `CollegeName`, `EmailId`, `Password`, `uploadpic`, `status`, `loginAs`, `Auth_Code`) VALUES
('Anjali', NULL, NULL, NULL, NULL, 'admin@gmail.com', '9v3/5IyQjesPTDvTbAMucg==', NULL, 1, 'admin', NULL),
('demo', 'radio', '2014-12-31', 'jjj', 'nkjh', 'surbhi2991@gmail.com', 'N2zrY8YIpd44yEz0l37vSg==', '3.jpg', 1, 'user', 'EHYmnpuWBwRq'),
(NULL, NULL, NULL, NULL, NULL, 'wipro@gmail.com', 'Is+WA+F6EUQ09+zxtfhEvg==', NULL, 1, 'company', 'rqmyGpw3BCPF'),
(NULL, NULL, NULL, NULL, NULL, 'genx.surbhi.jpr@gmail.com', 'Qpf0SxOVUjUkWySXOZ16kw==', NULL, 1, 'user', 'R3Jj$v9x*m2C');

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE IF NOT EXISTS `resume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `resum` varchar(255) DEFAULT NULL,
  `categry` varchar(255) DEFAULT NULL,
  `expyr` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `salary` varchar(255) DEFAULT NULL,
  `cmpnyadd` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `resume`
--

INSERT INTO `resume` (`id`, `name`, `email`, `contact`, `resum`, `categry`, `expyr`, `company`, `designation`, `salary`, `cmpnyadd`) VALUES
(13, 'aarti gugalia', 'serwa@gmail.com', '9876543211', 'resume1.doc', 'Fresher', 'null', 'null', 'null', 'null', 'null'),
(5, 'Party', 'partyprinces@gmail.com', '3456782192', 'resume1.doc', 'freshers', NULL, NULL, NULL, NULL, NULL),
(14, 'anjali', 'partyprinces@gmail.com', '9649978655', 'ritucv.doc', 'Fresher', 'null', 'null', 'null', 'null', 'null');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
